package com.jsp.Theatre_management_system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TheatreManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(TheatreManagementSystemApplication.class, args);
	}

}
