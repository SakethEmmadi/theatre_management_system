package com.jsp.Theatre_management_system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.Theatre_management_system.dto.Address;
import com.jsp.Theatre_management_system.service.AddressService;
import com.jsp.Theatre_management_system.util.ResponseStructure;
import com.jsp.Theatre_management_system.util.ResponseStructureList;

@RestController
public class AddressControllerClass {
	@Autowired
	AddressService addressService;

	@PostMapping("/saveAddress")
	public ResponseStructure<Address> saveAddress(@RequestBody Address address) {
		return addressService.saveAddress(address);
	}

	@GetMapping("/fetchAddressById")
	public ResponseStructure<Address> fetchAddressById(@RequestParam int addressId) {
		return addressService.fetchAddressById(addressId);
	}

	@GetMapping("/fetchAddressAll")
	public ResponseStructureList<Address> fetchAddressAll() {
		return addressService.fetchAddressAll();
	}

	@PutMapping("/updateAddress")
	public ResponseStructure<Address> updateAddress(@RequestParam int oldAddressId, @RequestBody Address newAddress) {
		return addressService.updateAddress(oldAddressId, newAddress);
	}

	@DeleteMapping("/deleteAddress")
	public ResponseStructure<Address> deleteAddress(@RequestParam int addressId) {
		return addressService.deleteAddressById(addressId);
	}
}
