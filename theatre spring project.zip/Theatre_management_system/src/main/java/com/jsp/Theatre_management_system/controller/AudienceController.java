package com.jsp.Theatre_management_system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.Theatre_management_system.dto.Audience;
import com.jsp.Theatre_management_system.dto.Food;
import com.jsp.Theatre_management_system.service.AudienceService;
import com.jsp.Theatre_management_system.util.ResponseStructure;
import com.jsp.Theatre_management_system.util.ResponseStructureList;

@RestController
public class AudienceController {
	@Autowired
	AudienceService audienceService;

	@PostMapping("/saveAudience")
	public ResponseStructure<Audience> saveAudience(@RequestBody Audience audience) {
		return audienceService.saveAudience(audience);
	}

	@GetMapping("/fetchAudienceById")
	public ResponseStructure<Audience> fetchAudienceById(@RequestParam int audienceId) {
		return audienceService.fetchAudienceById(audienceId);
	}

	@GetMapping("/fetchAudienceAll")
	public ResponseStructureList<Audience> fetchAudienceAll() {
		return audienceService.fetchAudienceAll();
	}

	@PutMapping("/updateAudience")
	public ResponseStructure<Audience> updateAudience(@RequestParam int oldAudienceId, @RequestBody Audience newAudience) {
		return audienceService.updateAudience(oldAudienceId, newAudience);
	}

	@DeleteMapping("/deleteAudience")
	public ResponseStructure<Audience> deleteAudience(@RequestParam int audienceId) {
		return audienceService.deleteAudienceById(audienceId);
	}
	
	@PutMapping("/addExistingAudienceToExistingFood")
	public ResponseStructure<Audience> addExistingAudienceToExistingFood(@RequestParam int audienceId,@RequestParam int foodId) {
		return audienceService.addExistingAudienceToExistingFood(audienceId, foodId);
	}
	@PutMapping("/addNewFoodToExistingAudience")
	public ResponseStructure<Audience> addNewFoodToExistingAudience(@RequestParam int audienceId,@RequestBody Food newFood) {
		return audienceService.addNewFoodToExistingAudience(audienceId, newFood);
	
	}
}
