
package com.jsp.Theatre_management_system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.Theatre_management_system.dto.Address;
import com.jsp.Theatre_management_system.dto.Branch;
import com.jsp.Theatre_management_system.dto.Employee;
import com.jsp.Theatre_management_system.dto.Manager;
import com.jsp.Theatre_management_system.service.BranchService;
import com.jsp.Theatre_management_system.util.ResponseStructure;
import com.jsp.Theatre_management_system.util.ResponseStructureList;

@RestController
public class BranchController {
	@Autowired
	BranchService branchService;

	@PostMapping("/saveBranch")
	public ResponseStructure<Branch> saveBranch(@RequestBody Branch branch) {
		return branchService.saveBranch(branch);
	}

	@GetMapping("/fetchBranchById")
	public ResponseStructure<Branch> fetchBranchById(@RequestParam int branchId) {
		return branchService.fetchBranchById(branchId);
	}

	@GetMapping("/fetchBranchAll")
	public ResponseStructureList<Branch> fetchBranchAll() {
		return branchService.fetchBranchAll();
	}

	@PutMapping("/updateBranch")
	public ResponseStructure<Branch> updateBranch(@RequestParam int oldBranchId, @RequestBody Branch newBranch) {
		newBranch.setBranchId(oldBranchId);
		return saveBranch(newBranch);
	}

	@DeleteMapping("/deleteBranch")
	public ResponseStructureList<Branch> deleteBranch(@RequestParam int branchId) {
		return branchService.deleteBranchById(branchId);
	}

	@PutMapping("/addExistingBranchToExistingAddress")
	public ResponseStructure<Branch> addExistingBranchToExistingAddress(@RequestParam int branchId, @RequestParam int addressId) {
		return branchService.addExistingBranchToExistingAddress(branchId, addressId);
	}

	@PutMapping("/addNewAddressToExistingBranch")
	public ResponseStructure<Branch> addNewAddressToExistingBranch(@RequestParam int branchId, @RequestBody Address address) {
		return branchService.addNewAddressToExistingBranch(branchId, address);
	}

	@PutMapping("/addExistingBranchToExistingManager")
	public ResponseStructure<Branch> addExistingBranchToExistingManager(@RequestParam int branchId, @RequestParam int managerId) {
		return branchService.addExistingBranchToExistingManager(branchId, managerId);
	}

	@PutMapping("/addNewManagerToExistingBranch")
	public ResponseStructure<Branch> addNewManagerToExistingBranch(@RequestParam int branchId, @RequestBody Manager manager) {
		return branchService.addNewManagerToExistingBranch(branchId, manager);
	}

	@PutMapping("/addExistingBranchToExistingEmployee")
	public ResponseStructure<Branch> addExistingBranchToExistingEmployee(@RequestParam int branchId, @RequestParam int employeeId) {
		return branchService.addExistingBranchToExistingEmployee(branchId, employeeId);
	}

	@PutMapping("/addNewEmployeeToExistingBranch")
	public ResponseStructure<Branch> addNewEmployeeToExistingBranch(@RequestParam int branchId, @RequestBody Employee newEmployee) {
		return branchService.addNewEmployeeToExistingBranch(branchId, newEmployee);
	}
}
