package com.jsp.Theatre_management_system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.Theatre_management_system.dto.Food;
import com.jsp.Theatre_management_system.service.FoodService;
import com.jsp.Theatre_management_system.util.ResponseStructure;
import com.jsp.Theatre_management_system.util.ResponseStructureList;

@RestController
public class FoodController {
	@Autowired
	FoodService foodService;

	@PostMapping("/saveFood")
	public ResponseStructure<Food> saveFood(@RequestBody Food food) {
		return foodService.saveFood(food);
	}

	@GetMapping("/fetchFoodById")
	public ResponseStructure<Food> fetchFoodById(@RequestParam int foodId) {
		return foodService.fetchFoodById(foodId);
	}

	@GetMapping("/fetchFoodAll")
	public ResponseStructureList<Food> fetchFoodAll() {
		return foodService.fetchFoodAll();
	}

	@PutMapping("/updateFood")
	public ResponseStructure<Food> updateFood(@RequestParam int oldFoodId, @RequestBody Food newFood) {
		newFood.setFoodId(oldFoodId);
		return foodService.updateFood(oldFoodId, newFood);
	}

	@DeleteMapping("/deleteFood")
	public ResponseStructure<Food> deleteFood(@RequestParam int foodId) {
		return foodService.deleteFoodById(foodId);
	}
}
