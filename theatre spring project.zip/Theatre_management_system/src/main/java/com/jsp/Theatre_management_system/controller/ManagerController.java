package com.jsp.Theatre_management_system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.Theatre_management_system.dto.Manager;
import com.jsp.Theatre_management_system.service.ManagerService;
import com.jsp.Theatre_management_system.util.ResponseStructure;
import com.jsp.Theatre_management_system.util.ResponseStructureList;

@RestController
public class ManagerController {
	@Autowired
	ManagerService managerService;

	@PostMapping("/saveManager")
	public ResponseStructure<Manager> saveManager(@RequestBody Manager manager) {
		return managerService.saveManager(manager);
	}

	@GetMapping("/fetchManagerById")
	public ResponseStructure<Manager> fetchManagerById(@RequestParam int managerId) {
		return managerService.fetchManagerById(managerId);
	}

	@GetMapping("/fetchManagerAll")
	public ResponseStructureList<Manager> fetchManagerAll() {
		return managerService.fetchManagerAll();
	}

	@PutMapping("/updateManager")
	public ResponseStructure<Manager> updateManager(@RequestParam int oldManagerId, @RequestBody Manager newManager) {
		newManager.setManagerId(oldManagerId);
		return managerService.updateManager(oldManagerId, newManager);
	}

	@DeleteMapping("/deleteManager")
	public ResponseStructure<Manager> deleteManager(@RequestParam int managerId) {
		return managerService.deleteManagerById(managerId);
	}
}
