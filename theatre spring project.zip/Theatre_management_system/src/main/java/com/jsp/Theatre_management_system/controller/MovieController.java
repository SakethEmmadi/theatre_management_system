package com.jsp.Theatre_management_system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.Theatre_management_system.dto.Audience;
import com.jsp.Theatre_management_system.dto.Movie;
import com.jsp.Theatre_management_system.dto.Ticket;
import com.jsp.Theatre_management_system.service.MovieService;
import com.jsp.Theatre_management_system.util.ResponseStructure;
import com.jsp.Theatre_management_system.util.ResponseStructureList;

@RestController
public class MovieController {

	@Autowired
	MovieService movieService;

	@PostMapping("/saveMovie")
	public ResponseStructure<Movie> saveMovie(@RequestBody Movie movie) {
		return movieService.saveMovie(movie);
	}

	@GetMapping("/fetchMovieById")
	public ResponseStructure<Movie> fetchMovieById(@RequestParam int movieId) {
		return movieService.fetchMovieById(movieId);
	}

	@GetMapping("/fetchMovieAll")
	public ResponseStructureList<Movie> fetchMovieAll() {
		return movieService.fetchMovieAll();
	}

	@PutMapping("/updateMovie")
	public ResponseStructure<Movie> updateMovie(@RequestParam int oldMovieId, @RequestBody Movie newMovie) {
		newMovie.setMovieId(oldMovieId);
		return movieService.updateMovie(oldMovieId, newMovie);
	}

	@DeleteMapping("/deleteMovie")
	public ResponseStructure<Movie> deleteMovie(@RequestParam int movieId) {
		return movieService.deleteMovieById(movieId);
	}

	@PutMapping("/addExistingMovieToExistingAudience")
	public ResponseStructure<Movie> addExistingMovieToExistingAudience(@RequestParam int movieId,
			@RequestParam int audienceId) {
		return movieService.addExistingMovieToExistingAudience(movieId, audienceId);
	}

	@PutMapping("/addNewAudienceToExistingMovie")
	public ResponseStructure<Movie> addNewAudienceToExistingMovie(@RequestParam int movieId,
			@RequestBody Audience newAudience) {
		return movieService.addNewAudienceToExistingMovie(movieId, newAudience);
	}

	@PutMapping("/addExistingMovieToExistingTicket")
	public ResponseStructure<Movie> addExistingMovieToExistingTicket(@RequestParam int movieId,
			@RequestParam int ticketId) {
		return movieService.addExistingMovieToExistingTicket(movieId, ticketId);
	}

	@PutMapping("/addNewTicketToExistingMovie")
	public ResponseStructure<Movie> addNewTicketToExistingMovie(@RequestParam int movieId,
			@RequestBody Ticket newTicket) {
		return movieService.addNewTicketToExistingMovie(movieId, newTicket);
	}
}
