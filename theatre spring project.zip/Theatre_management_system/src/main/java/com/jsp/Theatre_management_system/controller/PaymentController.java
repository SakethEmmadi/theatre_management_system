package com.jsp.Theatre_management_system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.Theatre_management_system.dto.Payment;
import com.jsp.Theatre_management_system.service.PaymentService;
import com.jsp.Theatre_management_system.util.ResponseStructure;
import com.jsp.Theatre_management_system.util.ResponseStructureList;

@RestController
public class PaymentController {
	@Autowired
	PaymentService paymentService;

	@PostMapping("/savePayment")
	public ResponseStructure<Payment> savePayment(@RequestBody Payment payment) {
		return paymentService.savePayment(payment);
	}

	@GetMapping("/fetchPaymentById")
	public ResponseStructure<Payment> fetchPaymentById(@RequestParam int paymentId) {
		return paymentService.fetchPaymentById(paymentId);
	}

	@GetMapping("/fetchPaymentAll")
	public ResponseStructureList<Payment> fetchPaymentAll() {
		return paymentService.fetchPaymentAll();
	}

	@PutMapping("/updatePayment")
	public ResponseStructure<Payment> updatePayment(@RequestParam int oldPaymentId, @RequestBody Payment newPayment) {
		newPayment.setPaymentId(oldPaymentId);
		return paymentService.updatePayment(oldPaymentId, newPayment);
	}

	@DeleteMapping("/deletePayment")
	public ResponseStructure<Payment> deletePayment(@RequestParam int paymentId) {
		return paymentService.deletePaymentById(paymentId);
	}
}
