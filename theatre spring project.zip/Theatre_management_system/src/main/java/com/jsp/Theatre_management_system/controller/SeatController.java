package com.jsp.Theatre_management_system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.Theatre_management_system.dto.Seat;
import com.jsp.Theatre_management_system.dto.Ticket;
import com.jsp.Theatre_management_system.service.SeatService;
import com.jsp.Theatre_management_system.util.ResponseStructure;
import com.jsp.Theatre_management_system.util.ResponseStructureList;

@RestController
public class SeatController {
	@Autowired
	SeatService seatService;

	@PostMapping("/saveSeat")
	public ResponseStructure<Seat> saveSeat(@RequestBody Seat seat) {
		return seatService.saveSeat(seat);
	}

	@GetMapping("/fetchSeatById")
	public ResponseStructure<Seat> fetchSeatById(@RequestParam int seatId) {
		return seatService.fetchSeatById(seatId);
	}

	@GetMapping("/fetchSeatAll")
	public ResponseStructureList<Seat> fetchSeatAll() {
		return seatService.fetchSeatAll();
	}

	@PutMapping("/updateSeat")
	public ResponseStructure<Seat> updateSeat(@RequestParam int oldSeatId, @RequestBody Seat newSeat) {
		newSeat.setSeatId(oldSeatId);
		return seatService.updateSeat(oldSeatId, newSeat);
	}

	@DeleteMapping("/deleteSeat")
	public ResponseStructure<Seat> deleteSeat(@RequestParam int seatId) {
		return seatService.deleteSeatById(seatId);
	}

	@PutMapping("/addExistingSeatToExistingTicket")
	public ResponseStructure<Seat> addExistingSeatToExistingTicket(@RequestParam int seatId,
			@RequestParam int ticketId) {
		return seatService.addExistingSeatToExistingTicket(seatId, ticketId);
	}

	@PutMapping("/addNewSeatToExistingTicket")
	public ResponseStructure<Seat> addNewSeatToExistingTicket(@RequestParam int seatId, @RequestBody Ticket ticket) {
		return seatService.addNewSeatToExistingTicket(seatId, ticket);
	}
}
