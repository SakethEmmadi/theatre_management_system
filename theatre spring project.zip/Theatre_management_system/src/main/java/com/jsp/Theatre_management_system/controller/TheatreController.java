package com.jsp.Theatre_management_system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.Theatre_management_system.dto.Branch;
import com.jsp.Theatre_management_system.dto.Theatre;
import com.jsp.Theatre_management_system.service.TheatreService;
import com.jsp.Theatre_management_system.util.ResponseStructure;
import com.jsp.Theatre_management_system.util.ResponseStructureList;

@RestController
public class TheatreController {
	@Autowired
	TheatreService theatreService;

	@PostMapping("/saveTheatre")
	public ResponseStructure<Theatre> saveTheatre(@RequestBody Theatre theatre) {
		return theatreService.saveTheatre(theatre);
	}

	@GetMapping("/fetchTheatreById")
	public ResponseStructure<Theatre> fetchTheatreById(@RequestParam int theatreId) {
		return theatreService.fetchTheatreById(theatreId);
	}

	@GetMapping("/fetchTheatreAll")
	public ResponseStructureList<Theatre> fetchTheatreAll() {
		return theatreService.fetchTheatreAll();
	}

	@PutMapping("/updateTheatre")
	public ResponseStructure<Theatre> updateTheatre(@RequestParam int oldTheatreId, @RequestBody Theatre newTheatre) {
		newTheatre.setTheatreId(oldTheatreId);
		return theatreService.updateTheatre(oldTheatreId, newTheatre);
	}

	@DeleteMapping("/deleteTheatre")
	public ResponseStructure<Theatre> deleteTheatre(@RequestParam int theatreId) {
		return theatreService.deleteTheatreById(theatreId);
	}

	@PutMapping("/addExistingBranchToExistingTheatre")
	public ResponseStructure<Theatre> addExistingBranchToExistingTheatre(@RequestParam int branchId,
			@RequestParam int theatreId) {
		return theatreService.addExistingBranchToExistingTheatre(branchId, theatreId);
	}

	@PutMapping("/addNewBranchToExistingTheatre")
	public ResponseStructure<Theatre> addNewBranchToExistingTheatre(@RequestParam int theatreId,
			@RequestBody Branch newBranch) {
		return theatreService.addNewBranchToExistingTheatre(theatreId, newBranch);
	}
}
