package com.jsp.Theatre_management_system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.Theatre_management_system.dto.Payment;
import com.jsp.Theatre_management_system.dto.Ticket;
import com.jsp.Theatre_management_system.service.TicketService;
import com.jsp.Theatre_management_system.util.ResponseStructure;
import com.jsp.Theatre_management_system.util.ResponseStructureList;

@RestController
public class TicketController {
	@Autowired
	TicketService ticketService;

	@PostMapping("/saveTicket")
	public ResponseStructure<Ticket> saveTicket(@RequestBody Ticket ticket) {
		return ticketService.saveTicket(ticket);
	}

	@GetMapping("/fetchTicketById")
	public ResponseStructure<Ticket> fetchTicketById(@RequestParam int ticketId) {
		return ticketService.fetchTicketById(ticketId);
	}

	@GetMapping("/fetchTicketAll")
	public ResponseStructureList<Ticket> fetchTicketAll() {
		return ticketService.fetchTicketAll();
	}

	@PutMapping("/updateTicket")
	public ResponseStructure<Ticket> updateTicket(@RequestParam int oldTicketId, @RequestBody Ticket newTicket) {
		newTicket.setTicketId(oldTicketId);
		return ticketService.updateTicket(oldTicketId, newTicket);
	}

	@DeleteMapping("/deleteTicket")
	public ResponseStructure<Ticket> deleteTicket(@RequestParam int ticketId) {
		return ticketService.deleteTicketById(ticketId);
	}

	@PutMapping("/addExistingTicketToExistingPayment")
	public ResponseStructure<Ticket> addExistingTicketToExistingPayment(@RequestParam int ticketId,
			@RequestParam int paymentId) {
		return ticketService.addExistingTicketToExistingPayment(ticketId, paymentId);
	}

	@PutMapping("/addNewTicketToExistingPayment")
	public ResponseStructure<Ticket> addNewTicketToExistingPayment(@RequestParam int ticketId,
			@RequestBody Payment payment) {
		return ticketService.addNewTicketToExistingPayment(ticketId, payment);
	}
}
