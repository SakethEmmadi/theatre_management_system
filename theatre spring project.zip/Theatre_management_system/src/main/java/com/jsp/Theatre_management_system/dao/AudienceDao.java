package com.jsp.Theatre_management_system.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jsp.Theatre_management_system.dto.Audience;
import com.jsp.Theatre_management_system.dto.Food;
import com.jsp.Theatre_management_system.repo.AudienceRepo;

@Repository
public class AudienceDao {

	@Autowired
	AudienceRepo audienceRepo;

	@Autowired
	FoodDao foodDao;

	public Audience saveAudience(Audience audience) {
		return audienceRepo.save(audience);
	}

	public Audience fetchAudienceById(int AudienceId) {
		Optional<Audience> dbAudience = audienceRepo.findById(AudienceId);
		if (dbAudience.isPresent()) {
			return dbAudience.get();
		} else {
			return null;
		}

	}

	public List<Audience> fetchAudienceAll() {
		return audienceRepo.findAll();
	}

	public Audience deleteAudienceById(int AudienceId) {
		Audience audience = fetchAudienceById(AudienceId);
		audienceRepo.delete(audience);
		return audience;
	}

	public Audience updateAudience(int oldAudienceId, Audience newAudience) {
		newAudience.setAudienceId(oldAudienceId);
		return saveAudience(newAudience);
	}

	public Audience addExistingAudienceToExistingFood(int audienceId, int foodId) {
		Food food = foodDao.fetchFoodById(foodId);
		Audience audience = fetchAudienceById(audienceId);
		List<Food> list = audience.getFoods();
		list.add(food);
		audience.setFoods(list);
		return saveAudience(audience);
	}

	public Audience addNewFoodToExistingAudience(int audienceId, Food newFood) {
		Audience audience = fetchAudienceById(audienceId);
		List<Food> list = audience.getFoods();
		list.add(newFood);
		audience.setFoods(list);
		return saveAudience(audience);
	}
}
