package com.jsp.Theatre_management_system.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jsp.Theatre_management_system.dto.Address;
import com.jsp.Theatre_management_system.dto.Branch;
import com.jsp.Theatre_management_system.dto.Employee;
import com.jsp.Theatre_management_system.dto.Manager;
import com.jsp.Theatre_management_system.repo.BranchRepo;

@Repository
public class BranchDao {
	@Autowired
	BranchRepo branchRepo;

	@Autowired
	AddressDao addressDao;

	@Autowired
	ManagerDao managerDao;

	@Autowired
	EmployeeDao employeeDao;

	public Branch saveBranch(Branch branch) {
		return branchRepo.save(branch);
	}

	public Branch fetchBranchById(int branchId) {
		Optional<Branch> dbBranch = branchRepo.findById(branchId);
		if (dbBranch.isPresent()) {
			return dbBranch.get();
		} else {
			return null;
		}

	}

	public List<Branch> fetchBranchAll() {
		return branchRepo.findAll();
	}

	public Branch deleteBranchById(int branchId) {
		Branch branch = fetchBranchById(branchId);
		branchRepo.delete(branch);
		return branch;
	}

	public Branch updateBranch(int oldBranchId, Branch newBranch) {
		newBranch.setBranchId(oldBranchId);
		return saveBranch(newBranch);
	}

	public Branch addExistingBranchToExistingAddress(int branchId, int addressId) {
		Branch branch = fetchBranchById(branchId);
		Address address = addressDao.fetchAddressById(addressId);
		branch.setAddress(address);
		return saveBranch(branch);
	}

	public Branch addNewAddressToExistingBranch(int branchId, Address address) {
		Branch branch = fetchBranchById(branchId);
		branch.setAddress(address);
		return saveBranch(branch);
	}

	public Branch addExistingBranchToExistingManager(int branchId, int managerId) {
		Branch branch = fetchBranchById(branchId);
		Manager manager = managerDao.fetchManagerById(managerId);
		branch.setManager(manager);
		return saveBranch(branch);
	}

	public Branch addNewManagerToExistingBranch(int branchId, Manager manager) {
		Branch branch = fetchBranchById(branchId);
		branch.setManager(manager);
		return saveBranch(branch);
	}

	public Branch addExistingBranchToExistingEmployee(int branchId, int employeeId) {
		Employee employee = employeeDao.fetchEmployeeById(employeeId);
		Branch branch = fetchBranchById(branchId);
		List<Employee> list = branch.getEmployees();
		list.add(employee);
		branch.setEmployees(list);
		return saveBranch(branch);
	}

	public Branch addNewEmployeeToExistingBranch(int branchId, Employee newEmployee) {
		Branch branch = fetchBranchById(branchId);
		List<Employee> list = branch.getEmployees();
		list.add(newEmployee);
		branch.setEmployees(list);
		return saveBranch(branch);
	}

}
