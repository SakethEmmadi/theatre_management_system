package com.jsp.Theatre_management_system.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jsp.Theatre_management_system.dto.Audience;
import com.jsp.Theatre_management_system.dto.Movie;
import com.jsp.Theatre_management_system.dto.Ticket;
import com.jsp.Theatre_management_system.repo.MovieRepo;

@Repository
public class MovieDao {

	@Autowired
	MovieRepo movieRepo;

	@Autowired
	AudienceDao audienceDao;

	@Autowired
	TicketDao ticketDao;

	public Movie saveMovie(Movie movie) {
		return movieRepo.save(movie);
	}

	public Movie fetchMovieById(int movieId) {
		Optional<Movie> dbMovie = movieRepo.findById(movieId);
		if (dbMovie.isPresent()) {
			return dbMovie.get();
		} else {
			return null;
		}
	}

	public List<Movie> fetchMovieAll() {
		return movieRepo.findAll();
	}

	public Movie deleteMovieById(int movieId) {
		Movie movie = fetchMovieById(movieId);
		movieRepo.delete(movie);
		return movie;
	}

	public Movie updateMovie(int oldMovieId, Movie newMovie) {
		newMovie.setMovieId(oldMovieId);
		return saveMovie(newMovie);
	}

	public Movie addExistingMovieToExistingAudience(int movieId, int audienceId) {
		Audience audience = audienceDao.fetchAudienceById(audienceId);
		Movie movie = fetchMovieById(movieId);
		List<Audience> list = movie.getAudience();
		list.add(audience);
		movie.setAudience(list);
		return saveMovie(movie);
	}

	public Movie addNewAudienceToExistingMovie(int movieId, Audience newAudience) {
		Movie movie = fetchMovieById(movieId);
		List<Audience> list = movie.getAudience();
		list.add(newAudience);
		movie.setAudience(list);
		return saveMovie(movie);
	}

	public Movie addExistingMovieToExistingTicket(int movieId, int ticketId) {
		Ticket ticket = ticketDao.fetchTicketById(ticketId);
		Movie movie = fetchMovieById(movieId);
		List<Ticket> list = movie.getTickets();
		list.add(ticket);
		movie.setTickets(list);
		return saveMovie(movie);
	}

	public Movie addNewTicketToExistingMovie(int movieId, Ticket newTicket) {
		Movie movie = fetchMovieById(movieId);
		List<Ticket> list = movie.getTickets();
		list.add(newTicket);
		movie.setTickets(list);
		return saveMovie(movie);
	}

}
