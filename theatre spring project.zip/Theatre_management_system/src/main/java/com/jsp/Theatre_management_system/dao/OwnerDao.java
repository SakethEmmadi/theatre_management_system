package com.jsp.Theatre_management_system.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jsp.Theatre_management_system.dto.Owner;
import com.jsp.Theatre_management_system.dto.Theatre;
import com.jsp.Theatre_management_system.repo.OwnerRepo;

@Repository
public class OwnerDao {

	@Autowired
	OwnerRepo ownerRepo;

	@Autowired
	TheatreDao theatreDao;

	public Owner saveOwner(Owner owner) {
		return ownerRepo.save(owner);
	}

	public Owner fetchOwnerById(int ownerId) {

		Optional<Owner> dbOwner = ownerRepo.findById(ownerId);
		if (dbOwner.isPresent()) {
			return dbOwner.get();
		} else {
			return null;
		}

	}

	public List<Owner> fetchOwnerAll() {
		return ownerRepo.findAll();
	}

	public Owner deleteOwnerById(int ownerId) {
		Owner owner = fetchOwnerById(ownerId);
		ownerRepo.delete(owner);
		return owner;
	}

	public Owner updateOwner(int oldOwnerId, Owner newOwner) {
		newOwner.setOwnerId(oldOwnerId);
		return saveOwner(newOwner);
	}

	public Owner addExistingTheatreToExistingOwner(int theatreId, int ownerId) {
		Owner owner = fetchOwnerById(ownerId);
		Theatre theatre = theatreDao.fetchTheatreById(theatreId);
		owner.setTheatre(theatre);
		return saveOwner(owner);
	}

	public Owner addNewTheatreToExistingOwner(Theatre newTheatre, int ownerId) {
		Owner owner = fetchOwnerById(ownerId);
		owner.setTheatre(newTheatre);
		return saveOwner(owner);
	}
}
