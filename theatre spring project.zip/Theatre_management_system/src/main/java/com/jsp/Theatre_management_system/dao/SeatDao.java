package com.jsp.Theatre_management_system.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jsp.Theatre_management_system.dto.Seat;
import com.jsp.Theatre_management_system.dto.Ticket;
import com.jsp.Theatre_management_system.repo.SeatRepo;

@Repository
public class SeatDao {

	@Autowired
	SeatRepo seatRepo;

	@Autowired
	TicketDao ticketDao;

	public Seat saveSeat(Seat seat) {
		return seatRepo.save(seat);
	}

	public Seat fetchSeatById(int seatId) {
		Optional<Seat> dbSeat = seatRepo.findById(seatId);
		if (dbSeat.isPresent()) {
			return dbSeat.get();
		} else {
			return null;
		}

	}

	public List<Seat> fetchSeatAll() {
		return seatRepo.findAll();
	}

	public Seat deleteSeatById(int seatId) {
		Seat seat = fetchSeatById(seatId);
		seatRepo.delete(seat);
		return seat;
	}

	public Seat updateSeat(int oldSeatId, Seat newSeat) {
		newSeat.setSeatId(oldSeatId);
		return saveSeat(newSeat);
	}

	public Seat addExistingSeatToExistingTicket(int seatId, int ticketId) {
		Seat seat = fetchSeatById(seatId);
		Ticket ticket = ticketDao.fetchTicketById(ticketId);
		seat.setTicket(ticket);
		return saveSeat(seat);
	}

	public Seat addNewSeatToExistingTicket(int seatId, Ticket ticket) {
		Seat seat = fetchSeatById(seatId);
		seat.setTicket(ticket);
		return saveSeat(seat);
	}

}
