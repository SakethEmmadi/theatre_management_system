package com.jsp.Theatre_management_system.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jsp.Theatre_management_system.dto.Branch;
import com.jsp.Theatre_management_system.dto.Theatre;
import com.jsp.Theatre_management_system.repo.TheatreRepo;

@Repository
public class TheatreDao {

	@Autowired
	TheatreRepo theatreRepo;

	@Autowired
	BranchDao branchDao;

	public Theatre saveTheatre(Theatre theatre) {
		return theatreRepo.save(theatre);
	}

	public Theatre fetchTheatreById(int theatreId) {
		Optional<Theatre> dbTheatre = theatreRepo.findById(theatreId);
		if (dbTheatre.isPresent()) {
			return dbTheatre.get();
		} else {
			return null;
		}
	}

	public List<Theatre> fetchTheatreAll() {
		return theatreRepo.findAll();
	}

	public Theatre deleteTheatreById(int theatreId) {
		Theatre theatre = fetchTheatreById(theatreId);
		theatreRepo.delete(theatre);
		return theatre;
	}

	public Theatre updateTheatre(int oldTheatreId, Theatre newTheatre) {
		newTheatre.setTheatreId(oldTheatreId);
		return saveTheatre(newTheatre);
	}

	public Theatre addExistingBranchToExistingTheatre(int branchId, int theatreId) {
		Branch branch = branchDao.fetchBranchById(branchId);
		Theatre theatre = fetchTheatreById(theatreId);
		List<Branch> list = theatre.getBranch();
		list.add(branch);
		theatre.setBranch(list);
		return saveTheatre(theatre);
	}

	public Theatre addNewBranchToExistingTheatre(int theatreId, Branch newBranch) {

		Theatre theatre = fetchTheatreById(theatreId);
		List<Branch> list = theatre.getBranch();
		list.add(newBranch);
		theatre.setBranch(list);
		return saveTheatre(theatre);
	}

}
