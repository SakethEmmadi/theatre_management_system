package com.jsp.Theatre_management_system.exception;

public class AudienceIdNotFound extends RuntimeException {
    private String message = "AudienceId not found in the DB";

 
    public String getMessage() {
        return message;
    }
}
