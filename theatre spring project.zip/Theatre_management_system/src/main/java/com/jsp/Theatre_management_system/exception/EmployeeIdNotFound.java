package com.jsp.Theatre_management_system.exception;

public class EmployeeIdNotFound extends RuntimeException {
    private String message = "EmployeeId not found in the DB";

    @Override
    public String getMessage() {
        return message;
    }
}
