package com.jsp.Theatre_management_system.exception;

public class FoodIdNotFound extends RuntimeException {
    private String message = "FoodId not found in the DB";

  
    public String getMessage() {
        return message;
    }
}
