package com.jsp.Theatre_management_system.exception;

public class ScreenIdNotFound extends RuntimeException {
    private String message = "ScreenId not found in the DB";

  
    public String getMessage() {
        return message;
    }
}
