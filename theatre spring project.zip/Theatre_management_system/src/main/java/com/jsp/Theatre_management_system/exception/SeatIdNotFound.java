package com.jsp.Theatre_management_system.exception;

public class SeatIdNotFound extends RuntimeException {
	private String message = "SeatId not found in the DB";

	public String getMessage() {
		return message;
	}
}
