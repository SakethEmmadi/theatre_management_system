package com.jsp.Theatre_management_system.exception;

public class TheatreIdNotFound extends RuntimeException {
	private String message = "TheatreId not found in the DB";

	public String getMessage() {
		return message;
	}
}
