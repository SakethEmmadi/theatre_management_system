package com.jsp.Theatre_management_system.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jsp.Theatre_management_system.dto.Audience;

public interface AudienceRepo extends JpaRepository<Audience, Integer>{

}
