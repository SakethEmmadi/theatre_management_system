package com.jsp.Theatre_management_system.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jsp.Theatre_management_system.dto.Screen;

public interface ScreenRepo extends JpaRepository<Screen, Integer> {

}
