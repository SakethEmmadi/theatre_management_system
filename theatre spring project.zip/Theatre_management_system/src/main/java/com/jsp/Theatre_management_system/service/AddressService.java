package com.jsp.Theatre_management_system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.jsp.Theatre_management_system.dao.AddressDao;
import com.jsp.Theatre_management_system.dto.Address;
import com.jsp.Theatre_management_system.util.ResponseStructure;
import com.jsp.Theatre_management_system.util.ResponseStructureList;

@Service
public class AddressService {

	@Autowired
	AddressDao addressDao;
	@Autowired
	ResponseStructure<Address> responseStructure;
	@Autowired
	ResponseStructureList<Address> responseStructureList;

	public ResponseStructure<Address> saveAddress(Address address) {
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setMesssage("Address successfully inserted into the database");
		responseStructure.setData(addressDao.saveAddress(address));
		return responseStructure;
	}

	public ResponseStructure<Address> fetchAddressById(int AddressId) {
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMesssage("Address successfully fetched from the database");
		responseStructure.setData(addressDao.fetchAddressById(AddressId));
		return responseStructure;
	}

	public ResponseStructureList<Address> fetchAddressAll() {
		responseStructureList.setStatusCode(HttpStatus.FOUND.value());
		responseStructureList.setMesssage("Addresses successfully fetched from the database");
		responseStructureList.setData(addressDao.fetchAddressAll());
		return responseStructureList;
	}

	public ResponseStructure<Address> deleteAddressById(int addressId) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Address successfully deleted from the database");
		responseStructure.setData(addressDao.deleteAddressById(addressId));
		return responseStructure;
	}

	public ResponseStructure<Address> updateAddress(int oldAddressId, Address newAddress) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Address successfully updated in the database");
		responseStructure.setData(addressDao.updateAddress(oldAddressId, newAddress));
		return responseStructure;
	}
}
