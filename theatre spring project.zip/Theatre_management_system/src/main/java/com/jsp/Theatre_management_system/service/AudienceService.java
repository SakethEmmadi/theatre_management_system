package com.jsp.Theatre_management_system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.jsp.Theatre_management_system.dao.AudienceDao;
import com.jsp.Theatre_management_system.dto.Audience;
import com.jsp.Theatre_management_system.dto.Food;
import com.jsp.Theatre_management_system.util.ResponseStructure;
import com.jsp.Theatre_management_system.util.ResponseStructureList;

@Service
public class AudienceService {

	@Autowired
	AudienceDao audienceDao;
	@Autowired
	ResponseStructure<Audience> responseStructure;
	@Autowired
	ResponseStructureList<Audience> responseStructureList;

	public ResponseStructure<Audience> saveAudience(Audience audience) {
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setMesssage("Audience successfully inserted into the database");
		responseStructure.setData(audienceDao.saveAudience(audience));
		return responseStructure;
	}

	public ResponseStructure<Audience> fetchAudienceById(int audienceId) {
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMesssage("Audience successfully fetched from the database");
		responseStructure.setData(audienceDao.fetchAudienceById(audienceId));
		return responseStructure;
	}

	public ResponseStructureList<Audience> fetchAudienceAll() {
		responseStructureList.setStatusCode(HttpStatus.FOUND.value());
		responseStructureList.setMesssage("Audiences successfully fetched from the database");
		responseStructureList.setData(audienceDao.fetchAudienceAll());
		return responseStructureList;
	}

	public ResponseStructure<Audience> deleteAudienceById(int audienceId) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Audience successfully deleted from the database");
		responseStructure.setData(audienceDao.deleteAudienceById(audienceId));
		return responseStructure;
	}

	public ResponseStructure<Audience> updateAudience(int oldAudienceId, Audience newAudience) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Audience successfully updated in the database");
		responseStructure.setData(audienceDao.updateAudience(oldAudienceId, newAudience));
		return responseStructure;
	}

	public ResponseStructure<Audience> addExistingAudienceToExistingFood(int audienceId, int foodId) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Successfully added existing food to existing audience in the database");
		responseStructure.setData(audienceDao.addExistingAudienceToExistingFood(audienceId, foodId));
		return responseStructure;
	}

	public ResponseStructure<Audience> addNewFoodToExistingAudience(int audienceId, Food newFood) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Successfully added new food to existing audience in the database");
		responseStructure.setData(audienceDao.addNewFoodToExistingAudience(audienceId, newFood));
		return responseStructure;
	}
}
