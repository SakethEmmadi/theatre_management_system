package com.jsp.Theatre_management_system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.jsp.Theatre_management_system.dao.BranchDao;
import com.jsp.Theatre_management_system.dto.Address;
import com.jsp.Theatre_management_system.dto.Branch;
import com.jsp.Theatre_management_system.dto.Employee;
import com.jsp.Theatre_management_system.dto.Manager;
import com.jsp.Theatre_management_system.util.ResponseStructure;
import com.jsp.Theatre_management_system.util.ResponseStructureList;

@Service
public class BranchService {

	@Autowired
	BranchDao branchDao;
	@Autowired
	ResponseStructure<Branch> responseStructure;
	@Autowired
	ResponseStructureList<Branch> responseStructureList;

	public ResponseStructure<Branch> saveBranch(Branch branch) {
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setMesssage("Branch successfully inserted into the database");
		responseStructure.setData(branchDao.saveBranch(branch));
		return responseStructure;
	}

	public ResponseStructure<Branch> fetchBranchById(int branchId) {
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMesssage("Branch successfully fetched from the database");
		responseStructure.setData(branchDao.fetchBranchById(branchId));
		return responseStructure;
	}

	public ResponseStructureList<Branch> fetchBranchAll() {
		responseStructureList.setStatusCode(HttpStatus.FOUND.value());
		responseStructureList.setMesssage("Branches successfully fetched from the database");
		responseStructureList.setData(branchDao.fetchBranchAll());
		return responseStructureList;
	}

	public ResponseStructureList<Branch> deleteBranchById(int branchId) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Branch successfully deleted from the database");
		responseStructure.setData(branchDao.deleteBranchById(branchId));
		return responseStructureList;
	}

	public ResponseStructure<Branch> updateBranch(int oldBranchId, Branch newBranch) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Branch successfully updated in the database");
		responseStructure.setData(branchDao.updateBranch(oldBranchId, newBranch));
		return responseStructure;
	}

	public ResponseStructure<Branch> addExistingBranchToExistingAddress(int branchId, int addressId) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Successfully added existing branch to existing address in the database");
		responseStructure.setData(branchDao.addExistingBranchToExistingAddress(branchId, addressId));
		return responseStructure;
	}

	public ResponseStructure<Branch> addNewAddressToExistingBranch(int branchId, Address address) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Successfully added new address to existing branch in the database");
		responseStructure.setData(branchDao.addNewAddressToExistingBranch(branchId, address));
		return responseStructure;
	}

	public ResponseStructure<Branch> addExistingBranchToExistingManager(int branchId, int managerId) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Successfully added existing branch to existing manager in the database");
		responseStructure.setData(branchDao.addExistingBranchToExistingManager(branchId, managerId));
		return responseStructure;
	}

	public ResponseStructure<Branch> addNewManagerToExistingBranch(int branchId, Manager manager) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Successfully added new manager to existing branch in the database");
		responseStructure.setData(branchDao.addNewManagerToExistingBranch(branchId, manager));
		return responseStructure;
	}

	public ResponseStructure<Branch> addExistingBranchToExistingEmployee(int branchId, int employeeId) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Successfully added existing branch to existing employee in the database");
		responseStructure.setData(branchDao.addExistingBranchToExistingEmployee(branchId, employeeId));
		return responseStructure;
	}

	public ResponseStructure<Branch> addNewEmployeeToExistingBranch(int branchId, Employee newEmployee) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Successfully added new employee to existing branch in the database");
		responseStructure.setData(branchDao.addNewEmployeeToExistingBranch(branchId, newEmployee));
		return responseStructure;
	}
}
