package com.jsp.Theatre_management_system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.jsp.Theatre_management_system.dao.FoodDao;
import com.jsp.Theatre_management_system.dto.Food;
import com.jsp.Theatre_management_system.util.ResponseStructure;
import com.jsp.Theatre_management_system.util.ResponseStructureList;

@Service
public class FoodService {

	@Autowired
	FoodDao foodDao;
	@Autowired
	ResponseStructure<Food> responseStructure;
	@Autowired
	ResponseStructureList<Food> responseStructureList;

	public ResponseStructure<Food> saveFood(Food food) {
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setMesssage("Food successfully inserted into the database");
		responseStructure.setData(foodDao.saveFood(food));
		return responseStructure;
	}

	public ResponseStructure<Food> fetchFoodById(int foodId) {
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMesssage("Food successfully fetched from the database");
		responseStructure.setData(foodDao.fetchFoodById(foodId));
		return responseStructure;
	}

	public ResponseStructureList<Food> fetchFoodAll() {
		responseStructureList.setStatusCode(HttpStatus.FOUND.value());
		responseStructureList.setMesssage("Foods successfully fetched from the database");
		responseStructureList.setData(foodDao.fetchFoodAll());
		return responseStructureList;
	}

	public ResponseStructure<Food> deleteFoodById(int foodId) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Food successfully deleted from the database");
		responseStructure.setData(foodDao.deleteFoodById(foodId));
		return responseStructure;
	}

	public ResponseStructure<Food> updateFood(int oldFoodId, Food newFood) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Food successfully updated in the database");
		responseStructure.setData(foodDao.updateFood(oldFoodId, newFood));
		return responseStructure;
	}
}
