package com.jsp.Theatre_management_system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.jsp.Theatre_management_system.dao.ManagerDao;
import com.jsp.Theatre_management_system.dto.Manager;
import com.jsp.Theatre_management_system.util.ResponseStructure;
import com.jsp.Theatre_management_system.util.ResponseStructureList;

@Service
public class ManagerService {

	@Autowired
	ManagerDao managerDao;
	@Autowired
	ResponseStructure<Manager> responseStructure;
	@Autowired
	ResponseStructureList<Manager> responseStructureList;

	public ResponseStructure<Manager> saveManager(Manager manager) {
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setMesssage("Successfully manager inserted into DB");
		responseStructure.setData(managerDao.saveManager(manager));
		return responseStructure;
	}

	public ResponseStructure<Manager> fetchManagerById(int managerId) {
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMesssage("Successfully manager fetched from DB");
		responseStructure.setData(managerDao.fetchManagerById(managerId));
		return responseStructure;
	}

	public ResponseStructureList<Manager> fetchManagerAll() {
		responseStructureList.setStatusCode(HttpStatus.FOUND.value());
		responseStructureList.setMesssage("Successfully manager fecthed from DB");
		responseStructureList.setData(managerDao.fetchManagerAll());
		return responseStructureList;
	}

	public ResponseStructure<Manager> deleteManagerById(int managerId) {
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMesssage("Successfully manager deleted from DB");
		responseStructure.setData(managerDao.deleteManagerById(managerId));
		return responseStructure;
	}

	public ResponseStructure<Manager> updateManager(int oldManagerId, Manager newManager) {
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMesssage("Successfully manager updated in DB");
		responseStructure.setData(managerDao.updateManager(oldManagerId, newManager));
		return responseStructure;

	}

}
