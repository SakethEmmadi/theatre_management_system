package com.jsp.Theatre_management_system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.jsp.Theatre_management_system.dao.MovieDao;
import com.jsp.Theatre_management_system.dto.Audience;
import com.jsp.Theatre_management_system.dto.Movie;
import com.jsp.Theatre_management_system.dto.Ticket;
import com.jsp.Theatre_management_system.util.ResponseStructure;
import com.jsp.Theatre_management_system.util.ResponseStructureList;

@Service
public class MovieService {

	@Autowired
	MovieDao movieDao;
	@Autowired
	ResponseStructure<Movie> responseStructure;
	@Autowired
	ResponseStructureList<Movie> responseStructureList;

	public ResponseStructure<Movie> saveMovie(Movie movie) {
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setMesssage("Movie successfully inserted into the database");
		responseStructure.setData(movieDao.saveMovie(movie));
		return responseStructure;
	}

	public ResponseStructure<Movie> fetchMovieById(int movieId) {
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMesssage("Movie successfully fetched from the database");
		responseStructure.setData(movieDao.fetchMovieById(movieId));
		return responseStructure;
	}

	public ResponseStructureList<Movie> fetchMovieAll() {
		responseStructureList.setStatusCode(HttpStatus.FOUND.value());
		responseStructureList.setMesssage("Movies successfully fetched from the database");
		responseStructureList.setData(movieDao.fetchMovieAll());
		return responseStructureList;
	}

	public ResponseStructure<Movie> deleteMovieById(int movieId) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Movie successfully deleted from the database");
		responseStructure.setData(movieDao.deleteMovieById(movieId));
		return responseStructure;
	}

	public ResponseStructure<Movie> updateMovie(int oldMovieId, Movie newMovie) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Movie successfully updated in the database");
		responseStructure.setData(movieDao.updateMovie(oldMovieId, newMovie));
		return responseStructure;
	}

	public ResponseStructure<Movie> addExistingMovieToExistingAudience(int movieId, int audienceId) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Audience successfully added to the movie in the database");
		responseStructure.setData(movieDao.addExistingMovieToExistingAudience(movieId, audienceId));
		return responseStructure;
	}

	public ResponseStructure<Movie> addNewAudienceToExistingMovie(int movieId, Audience newAudience) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("New audience successfully added to the movie in the database");
		responseStructure.setData(movieDao.addNewAudienceToExistingMovie(movieId, newAudience));
		return responseStructure;
	}

	public ResponseStructure<Movie> addExistingMovieToExistingTicket(int movieId, int ticketId) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Ticket successfully added to the movie in the database");
		responseStructure.setData(movieDao.addExistingMovieToExistingTicket(movieId, ticketId));
		return responseStructure;
	}

	public ResponseStructure<Movie> addNewTicketToExistingMovie(int movieId, Ticket newTicket) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("New ticket successfully added to the movie in the database");
		responseStructure.setData(movieDao.addNewTicketToExistingMovie(movieId, newTicket));
		return responseStructure;
	}
}
