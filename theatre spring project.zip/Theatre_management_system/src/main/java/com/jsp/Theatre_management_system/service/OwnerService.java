package com.jsp.Theatre_management_system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.jsp.Theatre_management_system.dao.OwnerDao;
import com.jsp.Theatre_management_system.dto.Owner;
import com.jsp.Theatre_management_system.dto.Theatre;
import com.jsp.Theatre_management_system.exception.OwnerIdNotFound;
import com.jsp.Theatre_management_system.util.ResponseStructure;
import com.jsp.Theatre_management_system.util.ResponseStructureList;

@Service
public class OwnerService {

	@Autowired
	OwnerDao ownerDao;
	@Autowired
	ResponseStructure<Owner> responseStructure;
	@Autowired
	ResponseStructureList<Owner> responseStructureList;

	public ResponseStructure<Owner> saveOwner(Owner owner) {
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setMesssage("Owner successfully inserted into the database");
		responseStructure.setData(ownerDao.saveOwner(owner));
		return responseStructure;
	}

	public ResponseStructure<Owner> fetchOwnerById(int ownerId) {
		Owner owner=ownerDao.fetchOwnerById(ownerId);
		if(owner != null) {
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMesssage("Owner successfully fetched from the database");
		responseStructure.setData(ownerDao.fetchOwnerById(ownerId));
		return responseStructure;
		}
		else {
			throw new OwnerIdNotFound();
		}
	}

	public ResponseStructureList<Owner> fetchOwnerAll() {
		responseStructureList.setStatusCode(HttpStatus.FOUND.value());
		responseStructureList.setMesssage("Owners successfully fetched from the database");
		responseStructureList.setData(ownerDao.fetchOwnerAll());
		return responseStructureList;
	}

	public ResponseStructure<Owner> deleteOwnerById(int ownerId) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Owner successfully deleted from the database");
		responseStructure.setData(ownerDao.deleteOwnerById(ownerId));
		return responseStructure;
	}

	public ResponseStructure<Owner> updateOwner(int oldOwnerId, Owner newOwner) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Owner successfully updated in the database");
		responseStructure.setData(ownerDao.updateOwner(oldOwnerId, newOwner));
		return responseStructure;
	}

	public ResponseStructure<Owner> addExistingTheatreToExistingOwner(int theatreId, int ownerId) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Theatre successfully added to the owner in the database");
		responseStructure.setData(ownerDao.addExistingTheatreToExistingOwner(theatreId, ownerId));
		return responseStructure;
	}

	public ResponseStructure<Owner> addNewTheatreToExistingOwner(Theatre newTheatre, int ownerId) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("New theatre successfully added to the owner in the database");
		responseStructure.setData(ownerDao.addNewTheatreToExistingOwner(newTheatre, ownerId));
		return responseStructure;
	}
}
