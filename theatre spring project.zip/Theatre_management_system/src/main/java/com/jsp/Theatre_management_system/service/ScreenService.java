package com.jsp.Theatre_management_system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.jsp.Theatre_management_system.dao.ScreenDao;
import com.jsp.Theatre_management_system.dto.Movie;
import com.jsp.Theatre_management_system.dto.Screen;
import com.jsp.Theatre_management_system.dto.Seat;
import com.jsp.Theatre_management_system.util.ResponseStructure;
import com.jsp.Theatre_management_system.util.ResponseStructureList;

@Service
public class ScreenService {

	@Autowired
	ScreenDao screenDao;
	@Autowired
	ResponseStructure<Screen> responseStructure;
	@Autowired
	ResponseStructureList<Screen> responseStructureList;

	public ResponseStructure<Screen> saveScreen(Screen screen) {
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setMesssage("Screen successfully inserted into the database");
		responseStructure.setData(screenDao.saveScreen(screen));
		return responseStructure;
	}

	public ResponseStructure<Screen> fetchScreenById(int screenId) {
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMesssage("Screen successfully fetched from the database");
		responseStructure.setData(screenDao.fetchScreenById(screenId));
		return responseStructure;
	}

	public ResponseStructureList<Screen> fetchScreenAll() {
		responseStructureList.setStatusCode(HttpStatus.FOUND.value());
		responseStructureList.setMesssage("Screens successfully fetched from the database");
		responseStructureList.setData(screenDao.fetchScreenAll());
		return responseStructureList;
	}

	public ResponseStructure<Screen> deleteScreenById(int screenId) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Screen successfully deleted from the database");
		responseStructure.setData(screenDao.deleteScreenById(screenId));
		return responseStructure;
	}

	public ResponseStructure<Screen> updateScreen(int oldScreenId, Screen newScreen) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Screen successfully updated in the database");
		responseStructure.setData(screenDao.updateScreen(oldScreenId, newScreen));
		return responseStructure;
	}

	public ResponseStructure<Screen> addExistingScreenToExistingMovie(int screenId, int movieId) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Screen successfully added to the movie in the database");
		responseStructure.setData(screenDao.addExistingScreenToExistingMovie(screenId, movieId));
		return responseStructure;
	}

	public ResponseStructure<Screen> addNewMovieToExistingScreen(int screenId, Movie movie) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("New movie successfully added to the screen in the database");
		responseStructure.setData(screenDao.addNewMovieToExistingScreen(screenId, movie));
		return responseStructure;
	}

	public ResponseStructure<Screen> addExistingScreenToExistingSeat(int screenId, int seatId) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Screen successfully added to the seat in the database");
		responseStructure.setData(screenDao.addExistingScreenToExistingSeat(screenId, seatId));
		return responseStructure;
	}

	public ResponseStructure<Screen> addNewSeatToExistingScreen(int screenId, Seat newSeat) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("New seat successfully added to the screen in the database");
		responseStructure.setData(screenDao.addNewSeatToExistingScreen(screenId, newSeat));
		return responseStructure;
	}
}
