package com.jsp.Theatre_management_system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.jsp.Theatre_management_system.dao.SeatDao;
import com.jsp.Theatre_management_system.dto.Seat;
import com.jsp.Theatre_management_system.dto.Ticket;
import com.jsp.Theatre_management_system.util.ResponseStructure;
import com.jsp.Theatre_management_system.util.ResponseStructureList;

@Service
public class SeatService {

	@Autowired
	SeatDao seatDao;
	@Autowired
	ResponseStructure<Seat> responseStructure;
	@Autowired
	ResponseStructureList<Seat> responseStructureList;

	public ResponseStructure<Seat> saveSeat(Seat seat) {
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setMesssage("Seat successfully inserted into the database");
		responseStructure.setData(seatDao.saveSeat(seat));
		return responseStructure;
	}

	public ResponseStructure<Seat> fetchSeatById(int seatId) {
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMesssage("Seat successfully fetched from the database");
		responseStructure.setData(seatDao.fetchSeatById(seatId));
		return responseStructure;
	}

	public ResponseStructureList<Seat> fetchSeatAll() {
		responseStructureList.setStatusCode(HttpStatus.FOUND.value());
		responseStructureList.setMesssage("Seats successfully fetched from the database");
		responseStructureList.setData(seatDao.fetchSeatAll());
		return responseStructureList;
	}

	public ResponseStructure<Seat> deleteSeatById(int seatId) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Seat successfully deleted from the database");
		responseStructure.setData(seatDao.deleteSeatById(seatId));
		return responseStructure;
	}

	public ResponseStructure<Seat> updateSeat(int oldSeatId, Seat newSeat) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Seat successfully updated in the database");
		responseStructure.setData(seatDao.updateSeat(oldSeatId, newSeat));
		return responseStructure;
	}

	public ResponseStructure<Seat> addExistingSeatToExistingTicket(int seatId, int ticketId) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Seat successfully added to the ticket in the database");
		responseStructure.setData(seatDao.addExistingSeatToExistingTicket(seatId, ticketId));
		return responseStructure;
	}

	public ResponseStructure<Seat> addNewSeatToExistingTicket(int seatId, Ticket ticket) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("New seat successfully added to the ticket in the database");
		responseStructure.setData(seatDao.addNewSeatToExistingTicket(seatId, ticket));
		return responseStructure;
	}
}
