package com.jsp.Theatre_management_system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.jsp.Theatre_management_system.dao.TheatreDao;
import com.jsp.Theatre_management_system.dto.Branch;
import com.jsp.Theatre_management_system.dto.Theatre;
import com.jsp.Theatre_management_system.util.ResponseStructure;
import com.jsp.Theatre_management_system.util.ResponseStructureList;

@Service
public class TheatreService {

	@Autowired
	TheatreDao theatreDao;
	@Autowired
	ResponseStructure<Theatre> responseStructure;
	@Autowired
	ResponseStructureList<Theatre> responseStructureList;

	public ResponseStructure<Theatre> saveTheatre(Theatre theatre) {
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setMesssage("Theatre successfully inserted into the database");
		responseStructure.setData(theatreDao.saveTheatre(theatre));
		return responseStructure;
	}

	public ResponseStructure<Theatre> fetchTheatreById(int theatreId) {
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMesssage("Theatre successfully fetched from the database");
		responseStructure.setData(theatreDao.fetchTheatreById(theatreId));
		return responseStructure;
	}

	public ResponseStructureList<Theatre> fetchTheatreAll() {
		responseStructureList.setStatusCode(HttpStatus.FOUND.value());
		responseStructureList.setMesssage("Theatres successfully fetched from the database");
		responseStructureList.setData(theatreDao.fetchTheatreAll());
		return responseStructureList;
	}

	public ResponseStructure<Theatre> deleteTheatreById(int theatreId) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Theatre successfully deleted from the database");
		responseStructure.setData(theatreDao.deleteTheatreById(theatreId));
		return responseStructure;
	}

	public ResponseStructure<Theatre> updateTheatre(int oldTheatreId, Theatre newTheatre) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Theatre successfully updated in the database");
		responseStructure.setData(theatreDao.updateTheatre(oldTheatreId, newTheatre));
		return responseStructure;
	}

	public ResponseStructure<Theatre> addExistingBranchToExistingTheatre(int branchId, int theatreId) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Branch successfully added to the theatre in the database");
		responseStructure.setData(theatreDao.addExistingBranchToExistingTheatre(branchId, theatreId));
		return responseStructure;
	}

	public ResponseStructure<Theatre> addNewBranchToExistingTheatre(int theatreId, Branch newBranch) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("New branch successfully added to the theatre in the database");
		responseStructure.setData(theatreDao.addNewBranchToExistingTheatre(theatreId, newBranch));
		return responseStructure;
	}
}
