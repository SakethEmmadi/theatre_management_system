package com.jsp.Theatre_management_system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.jsp.Theatre_management_system.dao.TicketDao;
import com.jsp.Theatre_management_system.dto.Payment;
import com.jsp.Theatre_management_system.dto.Ticket;
import com.jsp.Theatre_management_system.util.ResponseStructure;
import com.jsp.Theatre_management_system.util.ResponseStructureList;

@Service
public class TicketService {

	@Autowired
	TicketDao ticketDao;
	@Autowired
	ResponseStructure<Ticket> responseStructure;
	@Autowired
	ResponseStructureList<Ticket> responseStructureList;

	public ResponseStructure<Ticket> saveTicket(Ticket ticket) {
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setMesssage("Ticket successfully inserted into the database");
		responseStructure.setData(ticketDao.saveTicket(ticket));
		return responseStructure;
	}

	public ResponseStructure<Ticket> fetchTicketById(int ticketId) {
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMesssage("Ticket successfully fetched from the database");
		responseStructure.setData(ticketDao.fetchTicketById(ticketId));
		return responseStructure;
	}

	public ResponseStructureList<Ticket> fetchTicketAll() {
		responseStructureList.setStatusCode(HttpStatus.FOUND.value());
		responseStructureList.setMesssage("Tickets successfully fetched from the database");
		responseStructureList.setData(ticketDao.fetchTicketAll());
		return responseStructureList;
	}

	public ResponseStructure<Ticket> deleteTicketById(int ticketId) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Ticket successfully deleted from the database");
		responseStructure.setData(ticketDao.deleteTicketById(ticketId));
		return responseStructure;
	}

	public ResponseStructure<Ticket> updateTicket(int oldTicketId, Ticket newTicket) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Ticket successfully updated in the database");
		responseStructure.setData(ticketDao.updateTicket(oldTicketId, newTicket));
		return responseStructure;
	}

	public ResponseStructure<Ticket> addExistingTicketToExistingPayment(int ticketId, int paymentId) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("Ticket successfully added to the payment in the database");
		responseStructure.setData(ticketDao.addExistingTicketToExistingPayment(ticketId, paymentId));
		return responseStructure;
	}

	public ResponseStructure<Ticket> addNewTicketToExistingPayment(int ticketId, Payment payment) {
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMesssage("New ticket successfully added to the payment in the database");
		responseStructure.setData(ticketDao.addNewTicketToExistingPayment(ticketId, payment));
		return responseStructure;
	}
}
