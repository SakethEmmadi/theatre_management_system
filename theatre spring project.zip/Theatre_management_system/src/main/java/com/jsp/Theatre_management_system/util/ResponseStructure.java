package com.jsp.Theatre_management_system.util;

import org.springframework.stereotype.Component;

@Component
public class ResponseStructure<T> {
	private int statusCode;
	private String messsage;
	private T data;

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public String getMesssage() {
		return messsage;
	}

	public void setMesssage(String messsage) {
		this.messsage = messsage;
	}

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}

}
